<?php

//define ("PB_CRYPT_LINKS" , "1");

function DoEvents($this) {
	global $_CONF , $_TSM;

	$_TSM["MENU"] = "";

	//checking if user is logged in
	if (!$_SESSION["minibase"]["user"]) {

		if ($_SERVER["REQUEST_METHOD"] == "POST") {

			//autentificate
			$user = $this->db->QFetchArray("select * from {$this->tables[users]} where `user_login` = '{$_POST[user]}' AND `user_password` = '{$_POST[pass]}'");

			if (is_array($user)) {
				$_SESSION["minibase"]["user"] = 1;
				$_SESSION["minibase"]["raw"] = $user;

				//redirecing to viuw sites
				header("Location: $_CONF[default_location]");
				exit;
			} else
				return $this->templates["login"]->blocks["Login"]->output;

		} else
			return $this->templates["login"]->blocks["Login"]->output;
	}
	if ($_SESSION["minibase"]["raw"]["user_level"] == 0) {
		$_TSM["MENU"] = $this->templates["login"]->blocks["MenuAdmin"]->output;
	} else {
		$_TSM["MENU"] = $this->templates["login"]->blocks["MenuUser"]->output;
	}

	if (!$_POST["task_user"])
		$_POST["task_user"] = $_SESSION["minibase"]["user"];

	if($_SESSION["minibase"]["raw"]["user_level"] == 1) {
		$_CONF["forms"]["adminpath"] = $_CONF["forms"]["userpath"];
	}

	switch ($_GET["sub"]) {
		case "logout":
			unset($_SESSION["minibase"]["user"]);
			header("Location: index.php");

			return $this->templates["login"]->EmptyVars();
		break;

		case "items":
		case "units":

			if (($_GET["sub"] == "units") && in_array($_GET["action"] , array("change"))) {
				$this->db->Query("UPDATE {$this->tables['units']} SET unit_status='{$_GET[unit_status]}' WHERE unit_id='{$_GET['unit_id']}'");
				header("Location: index.php?sub=units&unit_status=" . $_GET["cstatus"]);
				exit;
			}			

			if (($_GET["sub"] == "units") && in_array($_GET["action"] , array("" , "list"))) {


				$file = "units.search.xml";

				$data = new CForm($_CONF["forms"]["admintemplate"],$this->db,$this->tables);
				$task = new CSQLAdmin("units",  $_CONF["forms"]["admintemplate"],$this->db,$this->tables , $extra);
				$items = $task->form->SimpleList($task->forms["forms"]["list"], "" , "" , "" , false , true);
				if (is_array($items["items"])) {
					foreach ($items["items"] as $key => $val) {
						$items["items"][$key]["unit_status"] = $this->templates["common"]->blocks["Button"]->Replace(array(	
																	"button" => $val["unit_status"] == 2 ? "inactive" : "active",
																	"current_page" => urlencode(urlencode($_SERVER["REQUEST_URI"])),
																	"unit_id" => $val["unit_id"],
																	"unit_status" => $val["unit_status"] == 2 ? 1 : 2,
																	"status" => $_GET["unit_status"]
																));
					}					
				}				

				$extra["after"] = $task->form->SimpleList($task->forms["forms"]["list"], $items["items"] , $items["count"] , "" , false);			

				return $data->Show($_CONF["forms"]["adminpath"] . $file , array("values"=>$_GET) , $extra) . $CHAT_DATA;
			} else {

				if (($_GET["sub"] == "units") && ($_GET["action"] == "details") && ($_GET["export"] == "true")) {
					//read the unit
					$unit = $this->db->QFetchArray("SELECT * FROM {$this->tables['units']} WHERE unit_id={$_GET['unit_id']}");

					header("Content-Type: text/x-csv");
					header("Content-Disposition: inline; filename=" . urlencode($unit["unit_name"]) .".csv");
					header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
					header("Pragma: public");

					echo '"Unit Name","' . $unit["unit_name"] . '"' . "\n";
					echo '"Unit Number","' . $unit["unit_number"] . '"' . "\n\n";

					$end_date = mktime(23,59,59,$_GET['end_date_month'],$_GET['end_date_day'],$_GET['end_date_year']);
					$start_date = mktime(0,0,0,$_GET['start_date_month'],$_GET['start_date_day'],$_GET['start_date_year']);
					$cond = isset($_GET['start_date_month']) ? "item_date >= {$start_date} AND item_date <= {$end_date} AND " : "";
					
					$units = $this->db->QFetchRowArray("SELECT * FROM {$this->tables['items']} WHERE {$cond} item_unit={$_GET['unit_id']}");
					if (is_array($units)) {
						foreach ($units as $key => $unit) {
							echo date("m/d/Y" , $unit["item_date"]) . ",";
							echo "\"" . date("g:i a" , $unit["item_date"]) . "\",";
							echo "\"" . $unit["item_name"] . "\"\n";
						}						
					}
					

					die("");
				}

				if (($_GET["sub"] == "units") && ($_GET["action"] == "details")) {
					$task = new CSQLAdmin("items",  $_CONF["forms"]["admintemplate"],$this->db,$this->tables , $extra);
					$extra["details"]["after"] = $task->DoEvents();					
				}				

				$data = new CSQLAdmin($_GET["sub"],  $_CONF["forms"]["admintemplate"],$this->db,$this->tables , $extra);
				return $data->DoEvents();
			}

		break;

		case "Schedule":

				$file = "schedule.xml";

				$form = new CConfig($_CONF["forms"]["adminpath"] . $file);
				$form = $form->vars["form"];

				$data = new CForm($_CONF["forms"]["admintemplate"],$this->db,$this->tables);
				$task = new CSQLAdmin("units",  $_CONF["forms"]["admintemplate"],$this->db,$this->tables , $extra);
				$items = $task->form->SimpleList($task->forms["forms"]["list"], "" , "" , "" , false , true);
				if (is_array($items["items"])) {
					foreach ($items["items"] as $key => $val) {
						$_GET["unit_id"] = $val["unit_id"];

						$_items = new CSQLAdmin("items",  $_CONF["forms"]["admintemplate"],$this->db,$this->tables , $extra);
						$_items->forms["forms"]["list"]["subtitle"] = $val["unit_name"] . " / " . $val["unit_number"] ;
						$extra["after"].= $_items->DoEvents();
					}					
				}				

//				$extra["after"] = $task->form->SimpleList($task->forms["forms"]["list"], $items["items"] , $items["count"] , "" , false);			

				return $data->Show($form, array("values"=>$_GET) , $extra);

		break;


		case "users":
			
			if ((!$_GET["action"])&&($_SESSION["minibase"]["raw"]["user_level"] != 0 )) {
				$_GET["action"] = "details";				
			}

			if ($_SESSION["minibase"]["raw"]["user_level"] == 1) {
				$_GET["user_id"] = $_SESSION["minibase"]["raw"]["user_id"]; 
				$_POST["user_id"] = $_SESSION["minibase"]["raw"]["user_id"];
			}
			
			$data = new CSQLAdmin($_GET["sub"], $_CONF["forms"]["admintemplate"],$this->db,$this->tables);
			return $data->DoEvents();
		break;

		default:
			return "Welcome to Dispatch!";
		break;
	}
}

?>