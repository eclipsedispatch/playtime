-- phpMyAdmin SQL Dump
-- version 2.6.0-pl2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jan 03, 2005 at 10:14 PM
-- Server version: 4.0.18
-- PHP Version: 4.3.6
-- 
-- Database: `dispatch`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `site_items`
-- 

CREATE TABLE `site_items` (
  `item_id` int(11) NOT NULL auto_increment,
  `item_unit` int(11) NOT NULL default '0',
  `item_name` varchar(200) NOT NULL default '',
  `item_location` varchar(200) NOT NULL default '',
  `item_date` int(11) NOT NULL default '0',
  `item_post_user` int(11) NOT NULL default '0',
  `item_post_date` int(11) NOT NULL default '0',
  `item_post_ip` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`item_id`)
) TYPE=MyISAM AUTO_INCREMENT=9 ;

-- 
-- Dumping data for table `site_items`
-- 

INSERT INTO `site_items` VALUES (1, 5, 'Trip', 'Iasi', 1102625788, 1, 1102625788, '172.20.100.3');
INSERT INTO `site_items` VALUES (2, 5, 'Another Item', 'Dont know the Location', 1102630020, 3, 1102630044, '172.20.100.3');
INSERT INTO `site_items` VALUES (3, 5, 'Last item', 'Test bum', 1102630080, 3, 1102630089, '172.20.100.3');
INSERT INTO `site_items` VALUES (4, 2, 'Unit', 'test', 1102630980, 3, 1102630991, '172.20.100.3');
INSERT INTO `site_items` VALUES (5, 1, 'Pickup couch', '12 West Main', 1104849900, 3, 1104806732, '192.168.1.1');
INSERT INTO `site_items` VALUES (6, 1, 'Drop off dresser set.', '444 Park Street', 1104856500, 3, 1104806830, '192.168.1.1');
INSERT INTO `site_items` VALUES (7, 1, 'Drop off bed', '4569 Dennison Court', 1104851400, 3, 1104806870, '192.168.1.1');
INSERT INTO `site_items` VALUES (8, 1, 'Deliver replacement couch.', '111 Eastern', 1104867000, 3, 1104806909, '192.168.1.1');

-- --------------------------------------------------------

-- 
-- Table structure for table `site_units`
-- 

CREATE TABLE `site_units` (
  `unit_id` int(11) NOT NULL auto_increment,
  `unit_name` varchar(200) NOT NULL default '',
  `unit_number` varchar(100) NOT NULL default '',
  `unit_description` text NOT NULL,
  `unit_contact_name` varchar(100) NOT NULL default '',
  `unit_contact_phone` varchar(20) NOT NULL default '',
  `unit_contact_phone2` varchar(20) NOT NULL default '',
  `unit_status` int(1) NOT NULL default '0',
  `unit_post_user` int(11) NOT NULL default '0',
  `unit_post_ip` varchar(20) NOT NULL default '',
  `unit_post_date` int(11) NOT NULL default '0',
  PRIMARY KEY  (`unit_id`)
) TYPE=MyISAM AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `site_units`
-- 

INSERT INTO `site_units` VALUES (1, 'Taxi', 'IS-04-BIP', '1998 Ford Crown Vic. 133,000 miles. Good running car.', 'Joe Montana', '124-5555', '555-1212', 1, 0, '', 0);
INSERT INTO `site_units` VALUES (2, 'Car', 'IS-04-ECG', 'Another One', 'John Doe', '555-1212', '555-1234', 2, 0, '', 0);
INSERT INTO `site_units` VALUES (5, 'Another Unit', '1233312', 'This is the description of this unit.', 'Mary Doe', '555-1212', '444-1212', 1, 3, '172.20.100.3', 1102625788);

-- --------------------------------------------------------

-- 
-- Table structure for table `site_users`
-- 

CREATE TABLE `site_users` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_name` varchar(100) NOT NULL default '',
  `user_login` varchar(100) NOT NULL default '',
  `user_password` varchar(100) NOT NULL default '',
  `user_level` int(1) NOT NULL default '0',
  PRIMARY KEY  (`user_id`)
) TYPE=MyISAM AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `site_users`
-- 

INSERT INTO `site_users` VALUES (3, 'Site Administrator', 'admin', 'test', 0);
INSERT INTO `site_users` VALUES (2, 'Jon Doe', 'test', 'test', 1);
INSERT INTO `site_users` VALUES (4, 'Eod Noj', 'test2', 'test2', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `site_vars`
-- 

CREATE TABLE `site_vars` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) NOT NULL default '',
  `value` text NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `site_vars`
-- 

INSERT INTO `site_vars` VALUES (12, 'home', '1');
INSERT INTO `site_vars` VALUES (13, 'title', '15');
INSERT INTO `site_vars` VALUES (14, 'task_user', '1');
INSERT INTO `site_vars` VALUES (15, 'ipp', '5');
INSERT INTO `site_vars` VALUES (16, 'ppp', '4');
